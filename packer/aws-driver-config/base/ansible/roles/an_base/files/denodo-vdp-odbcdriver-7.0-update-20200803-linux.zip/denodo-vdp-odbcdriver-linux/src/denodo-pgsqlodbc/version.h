/* File:			version.h
 *
 * Description:		This file defines the driver version.
 *
 * Comments:		See "readme.txt" for copyright and license information.
 *
 */
// Changed by Denodo Technologies on 28/10/2019 to modify version number
// Changed by Denodo Technologies on 14/05/2019 to modify version number
// Changed by Denodo Technologies on 29/03/2019 to modify version number
// Changed by Denodo Technologies on 27/12/2018 to modify version number
// Changed by Denodo Technologies on 28/06/2018 to modify version number
// Changed by Denodo Technologies on 19/05/2017 to modify version number
// Changed by Denodo Technologies on 16/01/2017 to modify version number
// Changed by Denodo Technologies on 25/08/2016 to modify version number
// Changed by Denodo Technologies on 15/07/2016 to modify version number
// Changed by Denodo Technologies on 10/05/2016 to modify version number

#ifndef __VERSION_H__
#define __VERSION_H__

/*
 *	BuildAll may pass POSTGRESDRIVERVERSION, POSTGRES_RESOURCE_VERSION
 *	and PG_DRVFILE_VERSION via winbuild/psqlodbc.vcxproj.
 */
#ifndef POSTGRESDRIVERVERSION
#define POSTGRESDRIVERVERSION		"09.03.0505"
#endif
#ifndef POSTGRES_RESOURCE_VERSION
#define POSTGRES_RESOURCE_VERSION	POSTGRESDRIVERVERSION
#endif
#ifndef PG_DRVFILE_VERSION
#define PG_DRVFILE_VERSION		9,3,05,05
#endif

#endif
